package com.Appdaet.ServletChaining;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ResultServlet extends HttpServlet {
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException
	{
		String message = (String) request.getAttribute("message");
		boolean isValid = (boolean) request.getAttribute("isValid");
		
		response.setContentType("text/html");
		
		PrintWriter out = response.getWriter();
		
		out.println("<html><body>");
		out.println("<h1>Calculation Result</h1>");
		out.println("<hr>");
		
		if(isValid == true)
		{
			out.println("<h3>" + message + "</h3>");
		}
		out.println("<br><a href='calculate.html'>Return to Home</a>");
		out.println("</body></html>");
	}
}
