package com.Appdaet.ServletChaining;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class CalculateServlet extends HttpServlet {
	
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException
	{
		String number1 = request.getParameter("num1");
		String number2 = request.getParameter("num2");
		String options = request.getParameter("opts");
		String msg = null;
		boolean isValid = false;
		
		// retrieve the input field value and check if it is blank. If it is blank, store an error message in the request attribute.

		  if (number1.isEmpty() || number2.isEmpty()) {
		    request.setAttribute("errorMessage", "Both fields are required");
		    //if either fields is blank redirect to page.
		    response.sendRedirect("calculate.html");
		    return;
		  }
		
		int num1;
		int num2;
		
		try {
            num1 = Integer.parseInt(number1);
            num2 = Integer.parseInt(number2);
            
        
		if(options.equals("add")) {
			int add = num1 + num2;
			msg = "The answer is: " + add;
			isValid = true;
		}
		else if(options.equals("sub")) {
			int sub = num1 - num2;
			msg = "The answer is: " + sub;
			isValid = true;
		}
		else if(options.equals("mul")) {
			int mul = num1 * num2;
			msg = "The answer is: " + mul;
			isValid = true;
		}
		else if(options.equals("div")) {
			int div = num1 / num2;
			msg = "The answer is: " + div;
			isValid = true;
		}
		}
			catch (NumberFormatException e) {
		    request.setAttribute("errorMessage", "Both fields must be numbers");
		    request.getRequestDispatcher("/Result").forward(request, response);
		    return;
		  }
		
		request.setAttribute("isValid", isValid);
		request.setAttribute("message",msg);

		RequestDispatcher rd = request.getRequestDispatcher("/Result");
		rd.forward(request, response);
		
		
	}
}
