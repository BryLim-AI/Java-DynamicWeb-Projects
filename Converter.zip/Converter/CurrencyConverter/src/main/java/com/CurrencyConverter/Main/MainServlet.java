package com.CurrencyConverter.Main;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class MainServlet extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();

		out.println("<html><body>");
		out.println("<h1> Currency Converter </h1>");

		out.println("<form action='Result' ");
		out.println("<h3>Philippine Peso: <input type='text' name='peso' /> </h3> ");
		out.println("<h3>Foreign Currency:  <select name = \"currency\" id=\"currency\">\r\n"
		+ "        <option value=\"blk\"></option>\r\n"
		+ "        <option value=\"USD\">USD</option>\r\n"
		+ "        <option value=\"EURO\">EURO</option>\r\n"
		+ "        <option value=\"AUD\">AUD</option>\r\n"
		+ "    </select>  </h3> ");
		out.println("<input  type='submit' value='Submit'>");
		out.println("</form>");

		out.println("</body></html>");
		}

}
