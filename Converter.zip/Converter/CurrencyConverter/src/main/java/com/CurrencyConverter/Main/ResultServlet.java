package com.CurrencyConverter.Main;

import javax.servlet.http.HttpServlet;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ResultServlet extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
		String php = request.getParameter("peso");

		String options = request.getParameter("currency");
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.println("<html><body>");
		out.println("<h1>Results");
		out.println("<hr>");
		try {
		Double peso = Double.parseDouble(php);
		if(options.equals("USD") & peso > 0) {
		Double usd = peso / 42.65;
		out.println(" <p> The PHP amount of " + peso +" to " + options.toString()+ " conversion is " + usd + "</p>");
		}
		else if(options.equals("EURO")& peso > 0) {
		Double euro = peso / 60.50;
		out.println(" <p> The PHP amount of " + peso +" to " + options.toString()+ " conversion is " + euro + "</p>");
		}
		else if(options.equals("AUD")& peso > 0) {
		Double aud = peso / 42.00;
		out.println(" <p> The PHP amount of " + peso +" to " + options.toString()+ " conversion is " + aud + "</p>");
		}
		else {
		out.println("Please choose a currency / enter a value more than 0.");
		}
		}
		catch (NumberFormatException e){
		out.println("please input numbers. "); 
		}
		out.println("<br>");
		out.println("<a href='MainPage' style='font-size=12px;'> return to home </a>");
		out.println("</body></html>");		
		}

}
